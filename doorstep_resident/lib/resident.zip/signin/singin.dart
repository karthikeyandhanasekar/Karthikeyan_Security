
import 'dart:isolate';

import 'package:doorstep_resident/firestore.dart';
import 'package:doorstep_resident/platoformalertdialog.dart';
import 'package:doorstep_resident/show.dart';
import 'package:doorstep_resident/signin/authclass.dart';
import 'package:doorstep_resident/signin/register.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Signin extends StatefulWidget {
  

  @override
  _SigninState createState() => _SigninState();
}
  
  final _formKey = new GlobalKey<FormState>();
 TextEditingController emailcontrollers = new TextEditingController();
 TextEditingController passswordcontroller = new TextEditingController();

 String id;
 bool _isloading= false;

 String get emailid => emailcontrollers.text.trim();
   String get _password => passswordcontroller.text;
    

    

  String mailid =  emailid;
class _SigninState extends State<Signin> {
  
  


  Widget showEmailInput() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0.0, 100.0, 0.0, 0.0),
      child: new TextFormField(
        controller: emailcontrollers ,
        maxLines: 1,
        keyboardType: TextInputType.emailAddress,
        autofocus: false,
        enabled: _isloading == false,
        decoration: new InputDecoration(
            hintText: 'Email',
            icon: new Icon(
              Icons.mail,
              color: Colors.grey,
            )),
        validator: (value) => value.isEmpty ? 'Email can\'t be empty' : null,
        //onSaved: (value) => _email = value.trim(),
      ),
    );
  }

  Widget showPasswordInput() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0.0, 15.0, 0.0, 0.0),
      child: new TextFormField(
        controller: passswordcontroller,
        maxLines: 1,
        obscureText: true,
        autofocus: false,
        enabled: _isloading == false,
        decoration: new InputDecoration(
            hintText: 'Password',
            icon: new Icon(
              Icons.lock,
              color: Colors.grey,
            )),
        validator: (value) => value.isEmpty ? 'Password can\'t be empty' : null,
       // onSaved: (value) => _password = value.trim(),
      ),
    );
  }
  void  loginbutton(BuildContext context) async
 
  {
    setState(() {
      _isloading =  true;
    });
    print('Login button Called');
    try{
      await Future.delayed(Duration(seconds: 1));
    if(emailid != null && _password != null)
  
    {
          var  auth = Provider.of<BaseAuth>(context, listen:  false);
          auth.signin(emailid,_password);
          
       //AuthResult result =  await FirebaseAuth.instance.signInWithEmailAndPassword(email: _email,password: _password);
       //FirebaseUser user = result.user;
      // id = user.uid;
      // print(id);
       //Navigator.of(context).push(
         //MaterialPageRoute<void>(builder: (context) => Details()  ));
        Navigator.of(context).pop();

    }
    }catch(e)
    {
      print(e.toString());
      PlatformAlertDialog(
          cancelactiontext: 'Cancel',
          title: 'Login Failed',
          content: e.toString(),
          defaultactiontext: 'ok',
        ).show(context);

  
      
    } finally
    {
      setState(() {
         _isloading = false;
      });
    }
    
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Signin')
      ),
     // floatingActionButton: FloatingActionButton(onPressed: null, child: Icon(Icons.add)),

      body: Stack(
        children: <Widget>[
          showForm(context),
                  ],
                ),
          
                
              );
            }
            
          
        Widget    showForm(BuildContext context) {
          return new Container(
            padding: EdgeInsets.all(10.0),
            child : new Form(
              
              key: _formKey,
              child: ListView(
                padding: EdgeInsets.all(20.0),
                shrinkWrap: true,
                children: <Widget>[
                
                  showEmailInput(),
                  SizedBox(height : 10.0,),
                  showPasswordInput(),
                  SizedBox(height : 10.0,),
                  OutlineButton(onPressed: () => loginbutton(context),
                  textColor: Colors.blueGrey,
                  hoverColor: Colors.deepPurple,
                  child: Text('Login'),),
                      FlatButton(onPressed: () => register(), child: Text('No Account! Create your own account'))
                      
                                      ],
                                    )
                                  )
                                );
                              }
                      
                        register() {

                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (context) => Register())
                          );
                        }

}
