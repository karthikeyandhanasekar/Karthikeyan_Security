


import 'package:doorstep_resident/firestore.dart';
import 'package:doorstep_resident/signin/register.dart';
import 'package:flutter/material.dart';
import 'dart:convert';



class APIPath 
{
  
  
  static String senddata(String email,String jobid) => '/$email/$jobid';
  static String readdata(String email) => '/$email';


}