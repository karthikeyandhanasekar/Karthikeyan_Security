import 'dart:async';

import 'package:doorstep_resident/database/database.dart';
import 'package:doorstep_resident/firestore.dart';
import 'package:doorstep_resident/signin/authclass.dart';
import 'package:doorstep_resident/signin/landingpage.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:doorstep_resident/signin/register.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    User user;
    return Provider<BaseAuth>(
      create: (_) => Auth(),
      child:Provider<Database>(
        create: (_) => FirestoreDatabase(email: emailcontroller.text,blockid:null),
      child: MaterialApp(
          title: 'Chatting',
          theme: ThemeData.light()
          /*(
          brightness: Brightness.light,
          primaryColor: Colors.red,
          
          //primarySwatch: Colors.blue,
        ),*/
          ,
          darkTheme: ThemeData.dark(),
          debugShowCheckedModeBanner: false,
          home: LandingPage()),
    )
    );
  }
}
