




import 'package:flutter/material.dart';

class EmptyContent extends StatelessWidget {

  EmptyContent({this.title = 'Nothing here!',
  this.message = 'Add the new item '
  ,Key key}) : super(key : key);
  final String title ;
  final String message ;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Text(title,
        style: TextStyle(fontSize: 40.0,color : Colors.black),),
         Text(message,
        style: TextStyle(fontSize: 40.0,color : Colors.black),)
      ],
      
    );
  }
}