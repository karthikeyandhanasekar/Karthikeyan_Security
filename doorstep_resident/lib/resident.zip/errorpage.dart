import 'package:flutter/material.dart';
class errorpage extends StatelessWidget {
  final int stats;
  final String body;
  errorpage({this.stats,this.body});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  Text('$stats Error  message : $body'),
      
    );
  }
}