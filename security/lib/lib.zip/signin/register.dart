
import 'package:chatting/firestore.dart';
import 'package:chatting/show.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'authclass.dart';
import 'package:intl/intl.dart';


class Register extends StatefulWidget {
  //final BaseAuth auth;
 // Signin({this.auth});

  @override
  _RegisterState createState() => _RegisterState();
}
  
  final _formKey = new GlobalKey<FormState>();
 TextEditingController emailcontroller = new TextEditingController();
 TextEditingController passswordcontroller = new TextEditingController();

 String regblock, regdoor;

String collectionid =  '$regblock + $regdoor';

 

class _RegisterState extends State<Register> {
  void createRecord(String documentid) async {
      print(user);

  await databaseReference.collection("$collectionid")
      .document("Residentdetails")
      .setData({
        'Blockno' : regblock,
        'Doorno' : regdoor,
        'email' : _email,
        'Registered at' : DateTime.now().toIso8601String(),
      });

  DocumentReference ref = await databaseReference.collection("$documentid")
      .add({
        'Customername': '$customername ',
        'Customer number': '$customernumber',
        'Block ID' : '$blockno',
        'Door No ' : '$doorno',
        'Date ' : '$date',
        'Time' : '$time',
        'Reason' : '$purpose'
      });
  print(ref.documentID);
  print(token);
}
  
  String get _email => emailcontroller.text.trim();
   String get _password => passswordcontroller.text;
   

  Widget showEmailInput() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0.0, 100.0, 0.0, 0.0),
      child: new TextFormField(
        controller: emailcontroller ,
        maxLines: 1,
        keyboardType: TextInputType.emailAddress,
        autofocus: false,
        decoration: new InputDecoration(
            hintText: 'Email',
            icon: new Icon(
              Icons.mail,
              color: Colors.grey,
            )),
        validator: (value) => value.isEmpty ? 'Email can\'t be empty' : null,
        //onSaved: (value) => _email = value.trim(),
      ),
    );
  }

  Widget showPasswordInput() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(0.0, 15.0, 0.0, 0.0),
      child: new TextFormField(
        controller: passswordcontroller,
        maxLines: 1,
        obscureText: true,
        autofocus: false,
        decoration: new InputDecoration(
            hintText: 'Password',
            icon: new Icon(
              Icons.lock,
              color: Colors.grey,
            )),
        validator: (value) => value.isEmpty ? 'Password can\'t be empty' : null,
       // onSaved: (value) => _password = value.trim(),
      ),
    );
  }
  void  loginbutton(BuildContext context) async
 
  {
    try{
    if(regblock != null && regdoor != null && _email != null && _password != null)
  
    {
          final auth = Provider.of<BaseAuth>(context, listen:  false);
          
        await auth.signup(_email, _password);
        Navigator.of(context).push(
          MaterialPageRoute<void>(builder: (context) => Show()  ));
            }
    }catch(e)
    {
      print(e.toString());
    }
    
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Register')
      ),
      floatingActionButton: FloatingActionButton(onPressed: null, child: Icon(Icons.add)),

      body: Stack(
        children: <Widget>[
          showForm(context),
                  ],
                ),
          
                
              );
            }
            
          
        Widget    showForm(BuildContext context) {
          return new Container(
            padding: EdgeInsets.all(16.0),
            child : new Form(
              key: _formKey,
              child: ListView(
                shrinkWrap: true,
                children: <Widget>[
                  
                  showEmailInput(),
                  showPasswordInput(),
                  RaisedButton(onPressed: () => loginbutton(context),
    child: Text('Register'),)


                ],
              )
            )
          );
        }

}
