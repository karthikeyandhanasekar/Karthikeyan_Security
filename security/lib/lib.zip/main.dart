import 'dart:async';
import 'package:chatting/signin/authclass.dart';
import 'package:chatting/signin/landingpage.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Provider<BaseAuth>(
      create: (context) => Auth(),
      //lazy: false,
      
          child: MaterialApp(
        title: 'Chatting',
        theme: ThemeData.light(),
        darkTheme: ThemeData.dark(),
        debugShowCheckedModeBanner: false,
        home:LandingPage()),
      );
    
  }
}

