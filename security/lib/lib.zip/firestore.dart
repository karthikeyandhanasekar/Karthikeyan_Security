import 'package:chatting/database/database.dart';
import 'package:chatting/database/model.dart';
import 'package:chatting/signin/authclass.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:share/share.dart';
import 'package:flutter_sms/flutter_sms.dart';
import 'package:flutter_open_whatsapp/flutter_open_whatsapp.dart';

class APIPath1 extends Details {
  static String senddata(String block, String jobid) => '/$block/$jobid';
  static String readdata(String uid) => '/$uid';
}

class Details extends StatefulWidget {
  final Database database;
  //final String  uid;
  const Details({Key key, @required this.database}) : super(key: key);

  static Future<void> show(BuildContext context) async {
    final database = Provider.of<Database>(context, listen: false);
    await Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => Details(
              database: database,
            )));
  }

  @override
  _DetailsState createState() => _DetailsState();
}

TextEditingController blockcontroller = new TextEditingController();
TextEditingController doorcoltroller = new TextEditingController();
TextEditingController customercontroller = new TextEditingController();
TextEditingController customernumcontroller = new TextEditingController();
TextEditingController purposecontroller = new TextEditingController();

final databaseReference = Firestore.instance;

final String blockno = blockcontroller.text;
String doorno = doorcoltroller.text;
String customername = customercontroller.text;
String customernumber = customernumcontroller.text;
String purpose = purposecontroller.text;
String date = DateFormat.yMMMMEEEEd().format(DateTime.now());
String time = DateFormat.jm().format(DateTime.now());
String documentid = '$blockno' + '$doorno';

String uniqueres = '$blockno' + '$doorno';

String block, door, customer, number, reason;
String message =
    'DoorStep Security System \n \n\n\n\n Visitor: $customer ,\Visitor number: $number,\n  \n Date  : $date, \nTime : $time ,\n Reason : $reason';
String showmessage =
    ' Customername: $customername ,\n Customer number: $customernumber,\n Block ID : $blockno,\n  Door No  : $doorno, \n Date  : $date, \nTime : $time ';
//The variable 'Showmessage is must share to the file show.dart

User user;

String userid = user.uid;

var token = IdTokenResult;

final _formkey = GlobalKey<FormState>();

class _DetailsState extends State<Details> {
  void whatsapp(BuildContext context) async {
    String blockver = blockcontroller.text;
    String phonenumber;
    String custname = customercontroller.text;
    String custnum = customernumcontroller.text;
    String purpose = purposecontroller.text;
    if (blockver == 'dkkarthik2000@gmail.com') {
      phonenumber = '9123565978';
    }
    if (blockver == 'aakaash146@gmail.com') {
      phonenumber = '7871035199';
    }
    if (blockver == 'navinraj@gmail.com') {
      phonenumber = '7871666571';
    }

    final String allforone =
        'DoorStep Security System \n \n\n\n\n Visitor: $custname ,\nVisitor number: $custnum,\n Date  : $date, \nTime : $time ,\nReason : $purpose';
    FlutterOpenWhatsapp.sendSingleMessage("+91$phonenumber", allforone);
       blockcontroller.clear();
      doorcoltroller.clear();
      customernumcontroller.clear();
      customercontroller.clear();
      purposecontroller.clear();
  }

  bool _validateandSaveForm() {
    final form = _formkey.currentState;
    if (form.validate()) {
      form.save();
      return true;
    }
    return false;
  }

  void _submit() async {
    if (_validateandSaveForm()) {
      print('form saved : $reason and $number');
      final view = Senddata(
          blockid: block,
          Customername: customer,
          Customernumber: number,
          date: date,
          doorno: door,
          time: time,
          reason: reason,
          id: documentid);
      await widget.database.createviewer(view);
      Navigator.of(context).pop();
      String blockver = blockcontroller.text;
    String phonenumber;
    String custname = customercontroller.text;
    String custnum = customernumcontroller.text;
    String purpose = purposecontroller.text;
    if (blockver == 'dkkarthik2000@gmail.com') {
      phonenumber = '9123565978';
    }
    if (blockver == 'aakaash146@gmail.com') {
      phonenumber = '7871035199';
    }
    if (blockver == 'navinraj@gmail.com') {
      phonenumber = '7871666571';
    }

    final String allforone =
        'DoorStep Security System \n \n\n\n\n Visitor: $custname ,\nVisitor number: $custnum,\n Date  : $date, \nTime : $time ,\nReason : $purpose';
    FlutterOpenWhatsapp.sendSingleMessage("+91$phonenumber", allforone);
       blockcontroller.clear();
      doorcoltroller.clear();
      customernumcontroller.clear();
      customercontroller.clear();
      purposecontroller.clear();
    }
  }

  Future<FirebaseUser> firebaseUser() async {
    return await FirebaseAuth.instance
        .currentUser()
        .then((FirebaseUser user) async {
      userid = user.uid;
      print(userid);
    });
  }

  void share() async {
    final RenderBox box = context.findRenderObject();
    Share.share(message,
        subject: 'Hello',
        sharePositionOrigin: box.localToGlobal(Offset.zero) & box.size);
  }

  void sendSMS() async {
    List<String> recipents = ["7871666571", "7871032199"];
    String _result =
        await FlutterSms.sendSMS(message: message, recipients: recipents)
            .catchError((onError) {
      print(onError);
    });

    print(_result);
  }

  @override
  Widget build(BuildContext context) {
    //final database = Provider.of<Database>(context);

    User user;

    return Scaffold(
      appBar: AppBar(
        title: Text('Viewer details'),
        actions: <Widget>[
          IconButton(icon: Icon(Icons.share), onPressed: () => share())
        ],
      ),
      body: form(),
    );
  }

  Widget form() {
    return SingleChildScrollView(
      child: Form(
        key: _formkey,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: _buildformchildren()),
      ),
    );
  }

  void save(BuildContext context) async {
    try {
      final view = Senddata(
          blockid: blockno,
          Customername: customername,
          Customernumber: customernumber,
          date: date,
          doorno: doorno,
          time: time,
          reason: purpose,
          id: documentid);
      await widget.database.createviewer(view);
      blockcontroller.clear();
      doorcoltroller.clear();
      customernumcontroller.clear();
      customercontroller.clear();
      purposecontroller.clear();

      Navigator.of(context).pop();
    } catch (e) {
      print(e.toString());
    }
  }

  List<Widget> _buildformchildren() {
    return [
      TextFormField(
        controller: blockcontroller,
        decoration: InputDecoration(labelText: 'Block  and DoorID'),
        onSaved: (value) => block = value,
      ),
      
      TextFormField(
        controller: customercontroller,
        decoration: InputDecoration(labelText: 'Customer'),
        onSaved: (value) => customer = value,
      ),
      TextFormField(
        controller: customernumcontroller,
        decoration: InputDecoration(labelText: 'Customer number'),
        onSaved: (value) => number = value,
        keyboardType: TextInputType.numberWithOptions(),
      ),
      TextFormField(
        controller: purposecontroller,
        decoration: InputDecoration(labelText: 'Reason'),
        onSaved: (value) => reason = value,
      ),
      RaisedButton(
        onPressed: () => _submit(),
        child: Text('Save'),
      ),
      RaisedButton(
        onPressed: () => whatsapp(context),
        child: Text('Whatsapp'),
      )
    ];
  }
}
